import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.Arrays;
import java.util.Scanner;

public class LockerMe {

	public static void main(String[] args) throws IOException {

		System.out.println("Welcome to LockedMe.com- Developed by Taneya Nayak");
		System.out.println("---------------------------------------------------");
		int choice = 0;

		do {

			System.out.println("1. Retrieve the existing text files");
			System.out.println("2. File Operations");
			System.out.println("3. Exit");

			Scanner s = new Scanner(System.in);
			if(!s.hasNextInt()) {
				System.out.println("Please enter a number between 1,2,3");
				continue;
			}
			choice = s.nextInt();

			switch (choice)

			{

			case 1:
				listFileAndDirs();
				break;

			case 2:
				int choice1 = 0;
				do {

					System.out.println("1. Create a file");
					System.out.println("2. Search a file");
					System.out.println("3. Delete a file");
					System.out.println("4. Press 4 to go back to main menu");

					Scanner s1 = new Scanner(System.in);
					if(!s1.hasNextInt()) {
						System.out.println("Please enter a number between 1,2,3,4");
						continue;
					}
					choice1 = s1.nextInt();

					switch (choice1)

					{
					case 1:
						createFile();
						break;
					case 2:
						searchFile();
						break;
					case 3:

						deleteFile();
						break;

					// default:
					// System.out.println("Enter correct option");

					}
				} while (choice1 != 4);

				// System.out.println("You wanted to exit");

			default:

				// System.out.println("Please select the correct option");

			}
		} while (choice != 3);
		System.out.println("You have exited the application");
	}

	public static void listFileAndDirs() {

		System.out.println("Now following are the text files available in the directory:");
		System.out.println("------------------------------------------------------------");

		// try-catch block to handle exceptions

		try {
			File f = new File("/Users/taneya_nayak/eclipse-workspace/LockerRepository");

			FilenameFilter filter = new FilenameFilter() {
				@Override
				public boolean accept(File f, String name) {

					return name.endsWith(".txt");
				}
			};
			
			File files[] = f.listFiles(filter);
          
           Arrays.sort(files);
           for (File e : files)
           
           {

               if (e.isFile())    
               {
            	   
                  System.out.println("File: " + e.getName() + "  " + e.getAbsolutePath());
               }
           }
		
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}

	public static void createFile() throws IOException {
		System.out.println("Enter the number of files you want to create");
		Scanner s2 = new Scanner(System.in);
		
		if(!s2.hasNextInt())
		  { 
			System.out.println("Please enter an integer");
			createFile();
		  }
		else 
		{	
		int n = s2.nextInt();
		for (int i = 1; i <= n; i++) {
			System.out.print("Enter the desired name of your file without extension: ");

			Scanner s3 = new Scanner(System.in);
			String fileName = s3.nextLine();
			fileName = fileName + ".txt";
			File file = new File(fileName);
			file.createNewFile();
			System.out.println("File created sucessfully");
		}
		}
	}

	public static void searchFile() {

		boolean isFound = false;
		File folder = new File("/Users/taneya_nayak/eclipse-workspace/LockerRepository");
		File[] listOfFiles = folder.listFiles();
		System.out.print("Enter file name to search: ");
		Scanner s4 = new Scanner(System.in);
		String fileName = s4.nextLine();

		for (int i = 0; i < listOfFiles.length; i++) {
			if (listOfFiles[i].getName().startsWith(fileName)) {
				System.out.println(listOfFiles[i]);
				isFound = true;
			}
		}

		if(!isFound) {
			System.out.println("File not found");
		}
	}

	public static void deleteFile() {

		// File("/Users/taneya_nayak/eclipse-workspace/LockerRepository");

		System.out.print("Enter file name to delete including extension e.g taneya.txt: ");

		Scanner s5 = new Scanner(System.in);
		String fileName = s5.nextLine();
		File myfile = new File(fileName);
		if (myfile.delete()) {
			System.out.println("File deleted successfully");
		} else {
			System.out.println("File not found");
		}
	}
}
